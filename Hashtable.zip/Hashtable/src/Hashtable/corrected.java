package Hashtable;


import java.io.File;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

/**
 *
 * @author Safran
 */
public class corrected {


    public static void main(String[] args) {

        Scanner inputScanner = new Scanner(System.in);
        System.out.print("Enter your registration number: ");
        String regNum = inputScanner.nextLine();
        String inputFile = "file" + regNum.charAt(0) + ".txt";
        String outputFile = "wordsHK" + regNum.charAt(0) + ".txt";
        inputScanner.close();


        HashMap<String, Integer> wordHashes = new HashMap<String, Integer>(); //use hashmap to store words and their hash key

        try {
            int index = 0; //initialize index size 0
            BufferedReader reader = new BufferedReader(new FileReader(inputFile)); // read input file
            FileWriter writer = new FileWriter(outputFile); // write output file


            String line = reader.readLine(); // Read each line from input file

            while (line != null) {    //loop through each line
                String[] words = line.split("\\s+");   //split line into words

                for (String word : words) { //loop through each word
                    word = word.replaceAll("[^a-zA-Z]", ""); //remove other special characters

                    if (!word.isEmpty()) { //skip empty words
                        int hashKey = 0; //initialize hash key to 0



                        for (int i = 0; i < word.length(); i++) {     //loop through each word
                            char c = word.charAt(i);
                            if (c >= 'a' && c <= 'z') {      //get if the character is lower case
                                hashKey += c - 'a';          //add ASCII minus value of a
                            } else if (c >= 'A' && c <= 'Z') {   //if character is uppercase
                                hashKey += c - 'A' + 26;       // ASCII value of A
                            }
                        }


                        if (!wordHashes.containsKey(word)) { //if word is not already in hashmap
                            wordHashes.put(word, hashKey); //add word as key

                            writer.write(index+  "\t" + word + "\t" + hashKey + "\n"); //write output to file
                            index ++;
                        }
                    }
                }

                line = reader.readLine(); //read next line from input file
            }

            reader.close(); //close buffer reader
            writer.close(); //close file writer

            System.out.println("Total unique words:" +index); //length of index


        } catch (IOException e) { //handle IOException
            e.printStackTrace(); //Print the stack trace of exception
        }
    }

}
