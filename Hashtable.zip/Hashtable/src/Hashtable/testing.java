package Hashtable;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/**
 * Non-collision Hash Table implementation using Separate Chaining.
 * Each word is stored in a linked list at the corresponding hash table index.
 *
 * @author Safran
 */
public class testing {

    // Set the size of the hash table to a suitable number
    private static final int TABLE_SIZE = 181;
    // Set the values of the quadratic polynomial
    private static final int C1 = 1;
    private static final int C2 = 1;
    private static final int C3 = 0;

    public static void main(String[] args) throws IOException {

        // Create a scanner to read input from the console
        Scanner inputScanner = new Scanner(System.in);
        System.out.print("Enter your registration number: ");

        String regNum = inputScanner.nextLine();
        String inputFile = "file" + regNum.charAt(0) + ".txt"; // Construct the input file name based on the first character of the registration number
        String outputFile = "wordsHK" + regNum.charAt(0) + ".txt"; //construct the output file name
        inputScanner.close();
        String outputQFile = "wordsQHK" + regNum.charAt(0) + ".txt"; //construct quadratic output filename

        // Create a hash table as an array of linked lists
        LinkedList<String>[] hashTable = new LinkedList[TABLE_SIZE];

        // Create a set to keep track of the words already added to the hash table
        Set<String> wordSet = new HashSet<>();

        // Initialize the hash table with empty linked lists
        for (int i = 0; i < TABLE_SIZE; i++) {
            hashTable[i] = new LinkedList<>();
        }

        // Open the input file and read each line
        try (BufferedReader br = new BufferedReader(new FileReader(inputFile))) {
            String line;

            int index = 0; // Initialize index to 0
            while ((line = br.readLine()) != null) {

                // Split the line into words
                String[] words = line.split("\\W+");
                for (String word : words) {

                    // Check if the word contains only alphabetic letters
                    if (word.matches("[a-zA-Z]+")) {

                        // Compute the hash key for the word using Eq. (1)
                        int hashKey = 0;
                        for (int i = 0; i < word.length(); i++) { // loop through each word
                            char c = word.charAt(i);
                            if (c >= 'a' && c <= 'z') {
                                hashKey += c - 'a'; // Compute the hash key for lowercase letters
                            } else if (c >= 'A' && c <= 'Z') {
                                hashKey += c - 'A' + 26; // Compute the hash key for uppercase letters
                            }
                        }

                        // Check if the word has already been added to the hash table
                        if (!wordSet.contains(word)) {

                            // Add the word to the hash table using separate chaining
                            int hashIndex = hashKey % TABLE_SIZE; // Compute the hash index
                            hashTable[hashIndex].add(word); // Add the word to the linked list at the hash index
                            wordSet.add(word);


                            try (FileWriter fw = new FileWriter(outputFile, true)) {
                                fw.write(index + " " + word + " " + hashKey + "\n");
                            }

                            try (FileWriter fw = new FileWriter(outputQFile, true)) {
                                int newHashKey = 0;
                                fw.write(index + " " + word + " " + newHashKey + "\n");
                            }

                            index++;
                            break;
                        }
                    }
                }
            }
        }
    }
}



